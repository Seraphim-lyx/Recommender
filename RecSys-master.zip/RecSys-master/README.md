# RecSys
这是《推荐系统实践》中基于近邻的方法的代码实现。
数据集使用的是MovieLen中大小为100K的数据集。</br>
程序分为6个文件：</br>
UserCF:基于用户的算法</br>
UserCF_IIF：改进的基于用户的算法</br>
ItemCF：基于物品的算法</br>
ItemCF_IUF：改进的基于物品的算法</br>
LFM:隐因子模型算法 </br>
Evaluation：评价指标</br>
mainCF:主函数，读取数据和测试</br>

